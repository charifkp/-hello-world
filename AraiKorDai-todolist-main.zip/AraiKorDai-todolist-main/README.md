This is a simple To-Do-List command-line application written in Python. Users of the application will be able to perform the following tasks.

* Sign up and log in (login details are stored in a JSON file) 
* Create and edit a to-do-list item
* View all to-do-list items
* View to-do-list item details
    * Title
    * Details
    * Priority (high, low, mid)
    * Status (completed, pending)
    * Owner
    * Updated date
    * Created date
* Mark a to-do-list item as completed

