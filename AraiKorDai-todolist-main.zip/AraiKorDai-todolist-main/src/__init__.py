"""To-do list CLI application."""
